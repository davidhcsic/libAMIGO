function str = mexAMIGOinterface(input_file,output_file,use_obs,use_obs_sens,make)
src_file = which('mexAMIGOinterface');
if isempty(src_file), error('mexAMIGOinterface.m could not be located.'); end
src_dir = fileparts(src_file);

include_folders = {
    fullfile(src_dir,'include','include_amigo')
    fullfile(src_dir,'include','include_nl2sol')
    fullfile(src_dir,'include','include_mxInterface')
    fullfile(src_dir,'include','include_cvodes')
    fullfile(src_dir,'include','include_f2c')
    fullfile(src_dir,'include','include_de')
    fullfile(src_dir,'include','include_SRES')
};

src_files = {input_file, fullfile(src_dir,'src','src_mxInterface','amigo_mexFunction.c')};
platform = computer;
static_libs = {};
libs = {};
lib_paths = {};

switch platform
    case {'MACA64','MACI64'}
        libomp_prefix = '/opt/homebrew/opt/libomp';
        libomp_include = fullfile(libomp_prefix,'include');
        libomp_lib = fullfile(libomp_prefix,'lib');
        if ~isfile(fullfile(libomp_include,'omp.h')) || ...
                ~isfile(fullfile(libomp_lib,'libomp.dylib'))
            error(['OpenMP runtime not found under %s. Install it with ' ...
                'brew install libomp.'],libomp_prefix);
        end
        include_folders{end+1} = libomp_include;

        % Use the locally rebuilt archive first.  The bundled lib_maca64
        % archive was built against an older AMIGO_model layout; mixing it
        % with current headers makes pars resolve to pars_guess at runtime.
        if isfolder(fullfile(src_dir,'lib_mac64'))
            amigo_lib_dir = fullfile(src_dir,'lib_mac64');
        elseif isfolder(fullfile(src_dir,'lib_maca64'))
            amigo_lib_dir = fullfile(src_dir,'lib_maca64');
        else
            error('No lib_maca64/lib_mac64 directory under %s.',src_dir);
        end

        static_libs = {
            fullfile(amigo_lib_dir,'libmxInterface.a')
            fullfile(amigo_lib_dir,'libAMIGO.a')
            fullfile(amigo_lib_dir,'libf2c.a')
        };

        for k = 1:numel(static_libs)
            if ~isfile(static_libs{k}), error('Missing static library: %s',static_libs{k}); end
        end

        lib_paths{end+1} = fullfile(matlabroot,'bin',computer('arch'));
        lib_paths{end+1} = libomp_lib;
        libs = {'omp','mwblas','mwlapack'};

    case 'GLNXA64'
        lib_paths = {fullfile(src_dir,'lib_linux64'), fullfile(matlabroot,'bin','glnxa64')};
        libs = {'mxInterface','AMIGO','f2c','gomp','mwblas','mwlapack'};

    case 'GLNX86'
        lib_paths = {fullfile(src_dir,'lib_linux64'), fullfile(matlabroot,'bin','glnx86')};
        libs = {'mxInterface','AMIGO','f2c','mwblas','mwlapack'};

    otherwise
        error('Unsupported platform: %s',platform);
end

if ~make
    args = {'-DIMPORT','-output',output_file};
    for k = 1:numel(include_folders), args{end+1} = ['-I' include_folders{k}]; end

    if any(strcmp(platform,{'MACA64','MACI64'}))
        args{end+1} = ['CFLAGS=$CFLAGS -Xpreprocessor -fopenmp ' ...
            '-Wno-unknown-pragmas -Wno-error=implicit-function-declaration'];
        args{end+1} = ['LDFLAGS=$LDFLAGS -Wl,-rpath,' libomp_lib];
    end

    for k = 1:numel(lib_paths), args{end+1} = ['-L' lib_paths{k}]; end
    for k = 1:numel(static_libs), args{end+1} = static_libs{k}; end
    for k = 1:numel(libs), args{end+1} = ['-l' libs{k}]; end
    args = [args src_files];

    str = local_args_to_string('mex',args);
    fprintf('\nOpenMP-enabled MEX command:\n%s\n\n',str);
    mex(args{:});
else
    error('Full-C mode is disabled by this macOS build.');
end

use_obs = use_obs; %#ok<NASGU>
use_obs_sens = use_obs_sens; %#ok<NASGU>
end

function str = local_args_to_string(command,args)
parts = {command};
for k = 1:numel(args)
    a = args{k};
    if contains(a,' ') && ~startsWith(a,'CFLAGS=')
        parts{end+1} = ['"' a '"']; %#ok<AGROW>
    else
        parts{end+1} = a; %#ok<AGROW>
    end
end
str = strjoin(parts,' ');
end
