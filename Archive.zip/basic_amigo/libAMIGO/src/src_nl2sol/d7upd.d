/Users/davidhenriques/Desktop/after_clash/2026/SYNBIO/basic_amigo/libAMIGO/src/src_nl2sol/d7upd.o: \
  /Users/davidhenriques/Desktop/after_clash/2026/SYNBIO/basic_amigo/libAMIGO/src/src_nl2sol/d7upd.c \
  /Users/davidhenriques/Desktop/after_clash/2026/SYNBIO/basic_amigo/libAMIGO/include/include_f2c/f2c.h
